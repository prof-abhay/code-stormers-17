// Add event listener to form submission
document.getElementById('incident-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    // Send form data to server or handle it locally
    console.log(formData);
    alert('Incident report submitted successfully!');
});

