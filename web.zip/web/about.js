// Add event listener to window load event
window.addEventListener('load', () => {
    // Animate elements on page load
    const elements = document.querySelectorAll('.title, .description, .info-title, .info-list li');
    elements.forEach((element) => {
        element.style.opacity = 0;
        element.style.transform = 'translateY(50px)';
        setTimeout(() => {
            element.style.opacity = 1;
            element.style.transform = 'translateY(0)';
        }, 500);
    });
});